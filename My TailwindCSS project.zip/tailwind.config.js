module.exports = {
  content: ['./*.html']
}